export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDabrIm4nhsNkycvzRFoyo4yxriB4Uiwsg",
    authDomain: "clientpanelprod-d2aa4.firebaseapp.com",
    databaseURL: "https://clientpanelprod-d2aa4.firebaseio.com",
    projectId: "clientpanelprod-d2aa4",
    storageBucket: "clientpanelprod-d2aa4.appspot.com",
    messagingSenderId: "873827498077"
  }
};
